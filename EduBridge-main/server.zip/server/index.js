const express = require("express");
const cors = require("cors");

const schoolRoutes = require("./routes/schools");
const volunteerRoutes = require("./routes/volunteers");
const donationRoutes = require("./routes/donations");
const feedbackRoutes = require("./routes/feedback");
const adminRoutes = require("./routes/admin");
const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/schools", schoolRoutes);
app.use("/api/volunteers", volunteerRoutes);
app.use("/api/donations", donationRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/admin", adminRoutes);

app.get("/", (req, res) => {
  res.json({
    message: "HelpingHands API Running 🚀"
  });
});

const PORT = 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});