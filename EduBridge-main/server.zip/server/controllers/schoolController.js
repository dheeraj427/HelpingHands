const { read, write } = require("../utils/jsonDB");

const FILE = "schools.json";

const getAllSchools = (req, res) => {
  try {
    const schools = read(FILE).filter(
      school => school.status === "approved"
    );

    res.json(schools);
  } catch (err) {
    res.status(500).json({
      message: "Unable to fetch schools."
    });
  }
};

const getAllSchoolsAdmin = (req, res) => {
  try {
    const schools = read(FILE);
    res.json(schools);
  } catch (err) {
    res.status(500).json({
      message: "Unable to fetch schools."
    });
  }
};

const getSchoolById = (req, res) => {
  const schools = read(FILE);

  const school = schools.find(
    s => s._id === req.params.id
  );

  if (!school) {
    return res.status(404).json({
      message: "School not found"
    });
  }

  res.json(school);
};

const createSchool = (req, res) => {
  try {
    const schools = read(FILE);

    const newSchool = {
      _id: Date.now().toString(),
      name: req.body.name,
      location: req.body.location,
      principalName: req.body.principalName || "",
      principalMessage: req.body.principalMessage || "",
      overview: req.body.overview || "",
      facilities: req.body.facilities || [],
      gallery: req.body.gallery || [],
      contact: req.body.contact || "",
      email: req.body.email || "",
      status: "pending",
      createdAt: new Date().toISOString()
    };

    schools.push(newSchool);

    write(FILE, schools);

    res.status(201).json(newSchool);

  } catch (err) {

    res.status(500).json({
      message: "Unable to register school."
    });

  }
};

const updateSchoolStatus = (req, res) => {

  const schools = read(FILE);

  const index = schools.findIndex(
    s => s._id === req.params.id
  );

  if (index === -1) {

    return res.status(404).json({
      message: "School not found"
    });

  }

  schools[index].status = req.body.status;

  write(FILE, schools);

  res.json(schools[index]);

};

const deleteSchool = (req, res) => {

  let schools = read(FILE);

  const exists = schools.some(
    s => s._id === req.params.id
  );

  if (!exists) {

    return res.status(404).json({
      message: "School not found"
    });

  }

  schools = schools.filter(
    s => s._id !== req.params.id
  );

  write(FILE, schools);

  res.json({
    message: "School deleted successfully"
  });

};

module.exports = {
  getAllSchools,
  getAllSchoolsAdmin,
  getSchoolById,
  createSchool,
  updateSchoolStatus,
  deleteSchool
};